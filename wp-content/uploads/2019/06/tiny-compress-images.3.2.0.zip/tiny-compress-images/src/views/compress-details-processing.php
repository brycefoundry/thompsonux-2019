<div class="details-container" data-status="compressing" data-id="<?php echo $tiny_image->get_id() ?>">
	<div class="details">
		<span class="icon spinner"></span>
		<span class="message">
			<span><?php esc_html_e( 'compressing', 'tiny-compress-images' ) ?></span>
		</span>
	</div>
</div>
